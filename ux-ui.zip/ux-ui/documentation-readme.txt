HTML Document : 
	https://docs.pixelstrap.com/cuba/html/document/

React context Document : 
	https://react-cuba-doc.vercel.app/

Angular Document :
	https://angular-cuba-doc.vercel.app/

Vue Document :
	https://vue-cuba-doc-vuepixelstrap.vercel.app/

Django Document :
	https://docs.pixelstrap.com/cuba/django/document/

Flask Document :
   https://docs.pixelstrap.com/cuba/flask/document/ 

Node Document:
	https://docs.pixelstrap.com/cuba/node/document/

Laravel Document :      
	https://docs.pixelstrap.com/cuba/laravel/document/

Codeigniter Document:
    https://docs.pixelstrap.com/cuba/codeigniter/document/

Php Document:
	https://docs.pixelstrap.com/cuba/php/document/

Symfony Document:
	docs.pixelstrap.com/cuba/symfony/document
	
svelte  Document:	
	https://docs.pixelstrap.com/cuba/svelte/document/
	
NextJs Document:	
	https://cuba-nextjs.vercel.app/dashboard/default
	
Tailwind Document:	
	https://docs.pixelstrap.com/cuba/tailwind/document/
	
Angular Tailwind Document:
	https://docs.pixelstrap.com/cuba-tailwind/angular/document/
